#pragma once

double mySqrt(double input);
